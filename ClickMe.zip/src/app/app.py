from tkinter import *
from tkinter import messagebox
from datetime import datetime
import time


from grid_function import grid_widget, pack_widget

from email.mime.text import MIMEText
from email.mime.image import MIMEImage
from email.mime.application import MIMEApplication
from email.mime.multipart import MIMEMultipart
import smtplib
import os


root = Tk()

icon = root.iconbitmap("img/smiley_small.ico")
title = root.title("Click Me!")

window_width = 250
window_height = 220

# get the screen dimension
screen_width = root.winfo_screenwidth()
screen_height = root.winfo_screenheight()

# find the center point
center_x = int(screen_width/2 - window_width / 2)
center_y = int(screen_height/2 - window_height / 2)

# set the position of the window to the center of the screen
def size_update(window_width=window_width, window_height=window_height):
    root.geometry(f'{window_width}x{window_height}+{center_x}+{center_y}')

def size_maintain(window_width=window_width, window_height=window_height):
    root.geometry(f'{window_width}x{window_height}')

size_update()

#to disable resizing of the window
root.resizable(False, False)

bg = '#323434'
root.config(background=bg)

def format_time(time):
        return time.strftime("%I:%M:%S %p")
    
i = 3

with open('data/save.dat', 'r') as load_file:
    count = int(load_file.readline())

ftime_now = None
def count_click():
    root.geometry("250x220")
    result_text['text'] = ' '
    global i, count
    global ftime_now
    count+=1
    if count > 1:
        time_s = "times"
    else:
        time_s = "time"
    now = datetime.now()
    time_now = now.time()
    ftime_now = format_time(time_now)
    button_click['text']=(f'You clicked me {count} {time_s}')

    with open('data/save.dat', 'w') as save_file:
        save_file.write(f'{count}')

win = False

def enter_email():
    size_maintain()
    global win
    if not win:
        result_text['text'] = " "
        global email_window
        email_window = new_window(root)
        win = True
    else: 
        size_maintain(window_height=230)
        result_text['text'] = 'Window already exist.'

class new_window:

    def __init__(self, root):
        self.root = root
        email_win = Toplevel(root)
        self.email_win = email_win
        root_size = root.geometry()

        plus_loc = []
        for i, v in enumerate(root_size):
            if v == '+':
                plus_loc.append(int(i))
        
        current_xy = int(root_size[plus_loc[0]:plus_loc[1]])+25, int(root_size[plus_loc[1]:])+50

        def email_win_maintain():
            email_win.geometry(f'200x100+{current_xy[0]}+{current_xy[1]}')
        
        def email_win_update(window_width=200, window_height=120):
            email_win.geometry(f'{window_width}x{window_height}+{current_xy[0]}+{current_xy[1]}')

        email_win_maintain()

        res_submit = Label(email_win, text=" ")
        
        def submit_email():
            
            if len(email.get()) == 0:
                email_win_update(window_height=125)
                res_submit['text'] = 'No email address entered.'
            else:
                submit_btn.config(state=DISABLED)
                send_email(email.get())
                close_email_win()

        def close_email_win():
            global win
            win = False
            email_win.destroy()

        Label(email_win, text='Please enter your email').pack()
        email = Entry(email_win)
        email.pack()
        email_win.bind("<Return>", lambda e: submit_email())

        submit_btn = Button(email_win, text="Submit")
        submit_btn.config(border=1, command=submit_email)
        submit_btn.pack(pady=(20, 2))
        #submit_btn.bind('<Return>', lambda e: submit_email())
        res_submit.pack()
        email_win.protocol("WM_DELETE_WINDOW", close_email_win)
    
def close_window():

    if messagebox.askokcancel("Quit", "Do you want to quit?"):
        root.destroy()

def send_email(email_address):
    global count  
    try:
        smtp = smtplib.SMTP('smtp.gmail.com', 587)
        smtp.ehlo()
        smtp.starttls()  
        smtp.login('youclickedme.python@gmail.com', 'vkbmprxqydslgxdi')

        msg = MIMEMultipart()
        msg['Subject'] = 'Click App'
        msg.attach(MIMEText(f"Hello! You clicked me {count} times! The last click was on {datetime.now().date()} {format_time(datetime.now().time())}."))

        to = [email_address]
        smtp.sendmail(from_addr="youclickedme.python@gmail.com",
                    to_addrs=to, msg=msg.as_string())
        smtp.quit()

        size_update(window_height=250)
        result_text['text'] = "Email sent successfully."

    except smtplib.SMTPAuthenticationError as e:
        print(e)
        size_update(window_height=250)
        result_text['text'] = "An error occured.\n Please try again later."

    except smtplib.SMTPRecipientsRefused as e:
        print(e)
        size_update(window_height=250)
        result_text['text'] ="The email address you entered\n is not valid. Please try again."

    except Exception as e:
        size_update(window_height=250)
        result_text['text'] = "No internet connection"

#creating a Label widget
hello_world = Label(root, text='>>CLICK ME!')
my_name = Label(root, text='made by kenn')
click_me_btn = Button(root)
send_btn = Button(root)
void_label = Label(root, text= "   ")
button_click = Label(text=f'You clicked me {count} times!')
result_text = Label(text=" ")

img_btn = PhotoImage(file="img\smiley_small.png")
send_email_btn = PhotoImage(file="img\send_email_btn.png")

hello_world.config(bg=bg, fg='yellow', font=('Bahnschrift Bold', 22), anchor=CENTER)
my_name.config(bg=bg, fg='#ffffcc',  font=('Arial Italic', 8))
void_label.config(bg=bg)
button_click.config(bg=bg, fg='white', font=('Arial_Nova_Cond', 11))
click_me_btn.config(image=img_btn, bg=bg, activebackground=bg, padx=5, pady=5, cursor='heart', border=0)
send_btn.config(image=send_email_btn, padx=15, cursor='circle', activebackground=bg, bg=bg, borderwidth=0, command=enter_email)
result_text.config(bg=bg, fg='white')
#to bind all mouse events (left, scroll, right clicks)
click_me_btn.bind('<Button>', lambda btn: count_click())

#packs
hello_world.pack(pady=(8, 0))
pack_widget(my_name, click_me_btn, button_click)
send_btn.pack(pady=(5, 0))
result_text.pack()

root.protocol("WM_DELETE_WINDOW", close_window)
root.mainloop()
