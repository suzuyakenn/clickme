def grid_widget(widget, row, column):
    
    widget.grid(row=row, column=column)

def pack_widget(*widget):

    i = 0
    for i in range(len(widget)):
        widget[i].pack()
